# Parmecium

* A game called Parmecium, looks neet, works not so neet...

![Alt text](/data/Parmecium BIG.gif?raw=true "Parmecium")

